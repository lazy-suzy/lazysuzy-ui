import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-your-style',
  templateUrl: './create-your-style.component.html',
  styleUrls: ['./create-your-style.component.less']
})
export class CreateYourStyleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
