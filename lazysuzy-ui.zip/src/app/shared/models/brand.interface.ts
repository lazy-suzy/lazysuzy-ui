export interface IBrand {
  name: string;
  value: string;
  enabled: boolean;
  checked: boolean;
  count: number;
}